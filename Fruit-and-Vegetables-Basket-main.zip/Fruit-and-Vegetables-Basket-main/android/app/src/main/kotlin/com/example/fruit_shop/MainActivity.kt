package com.example.fruit_shop

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
