var product_on_the_cart=[
  {
    "name":"green apple",
    "picture":"assets/green_apple.jpg",
    "quantity":"40",
    "price": "25",
  },
  {
    "name":"tomato",
    "picture":"assets/tomato.jpg",
    "quantity":"15",
    "price": "10",
  },
  {
    "name":"carot",
    "picture":"assets/carrots.jpg",
    "quantity":"10",
    "price": "8",
  },
];