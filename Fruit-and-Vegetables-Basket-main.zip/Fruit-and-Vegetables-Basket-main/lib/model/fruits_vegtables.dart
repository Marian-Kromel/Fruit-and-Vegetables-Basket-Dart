class FruitsAndVegs {
  final String imagename;
  final String name;
  final double price;
  final String description;
  FruitsAndVegs(this.imagename, this.name, this.price, this.description);
}
